#ifndef __SERVER_H

#define __SERVER_H


#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#endif
