#ifndef __CLIENT_H

#define __CLIENT_H


#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#endif
